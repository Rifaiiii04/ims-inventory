#!/bin/bash
# Setup GPU untuk RTX 3050 - Copy Paste Script
# Untuk laptop teman dengan NVIDIA RTX 3050

echo "========================================"
echo "  Setup GPU untuk OCR & Expired Prediction"
echo "  NVIDIA RTX 3050"
echo "========================================"
echo ""

# Step 1: Cek CUDA
echo "[1/4] Checking CUDA..."
if command -v nvcc &> /dev/null; then
    echo "  ✓ CUDA detected"
    nvcc --version
else
    echo "  ✗ CUDA not found"
    echo "  → Download CUDA Toolkit: https://developer.nvidia.com/cuda-downloads"
    echo "  → Install CUDA 11.8 atau 12.x"
    exit 1
fi

# Step 2: Cek NVIDIA Driver
echo "[2/4] Checking NVIDIA Driver..."
if command -v nvidia-smi &> /dev/null; then
    echo "  ✓ NVIDIA Driver detected"
    nvidia-smi --query-gpu=name --format=csv,noheader
else
    echo "  ✗ NVIDIA Driver not found"
    echo "  → Install NVIDIA Driver dari: https://www.nvidia.com/drivers"
    exit 1
fi

# Step 3: Install PyTorch dengan CUDA
echo "[3/4] Installing PyTorch with CUDA 11.8..."
echo "  → This may take a few minutes..."

pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

if [ $? -eq 0 ]; then
    echo "  ✓ PyTorch installed successfully"
else
    echo "  ✗ PyTorch installation failed"
    echo "  → Try: pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121"
    exit 1
fi

# Step 4: Install EasyOCR (otomatis detect GPU)
echo "[4/4] Installing EasyOCR..."
pip install easyocr

if [ $? -eq 0 ]; then
    echo "  ✓ EasyOCR installed successfully"
else
    echo "  ✗ EasyOCR installation failed"
    exit 1
fi

# Step 5: Verifikasi GPU
echo ""
echo "[VERIFY] Testing GPU detection..."
python3 -c "import torch; print('GPU Available:', torch.cuda.is_available()); print('GPU Name:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'N/A'); print('CUDA Version:', torch.version.cuda if torch.cuda.is_available() else 'N/A')"

echo ""
echo "========================================"
echo "  ✓ Setup Complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "  1. Restart OCR service"
echo "  2. Test: curl http://localhost:5000/health"
echo "  3. Check GPU info in response"
echo ""
