# 🚀 Quick Setup GPU untuk RTX 3050

**Copy-paste script untuk setup GPU di laptop teman (RTX 3050)**

---

## 📋 Prerequisites (Lakukan Sekali)

### 1. Install CUDA Toolkit

-   Download: https://developer.nvidia.com/cuda-downloads
-   Pilih **CUDA 11.8** atau **12.x**
-   Install dengan default settings
-   **Restart laptop setelah install**

### 2. Install NVIDIA Driver (jika belum)

-   Download: https://www.nvidia.com/drivers
-   Install driver terbaru untuk RTX 3050

---

## ⚡ Quick Setup (Copy-Paste)

### Windows (PowerShell)

**Buka PowerShell di folder `python_ocr_service`, lalu copy-paste:**

```powershell
# Setup GPU untuk RTX 3050
.\setup_gpu.ps1
```

**Atau manual (copy-paste satu per satu):**

```powershell
# 1. Install PyTorch dengan CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# 2. Install EasyOCR
pip install easyocr

# 3. Test GPU
python test_gpu.py
```

### Linux/Mac

```bash
# Berikan permission
chmod +x setup_gpu.sh

# Run script
./setup_gpu.sh

# Atau manual
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
pip install easyocr
python3 test_gpu.py
```

---

## ✅ Verifikasi

### Test 1: Python Script

```bash
python test_gpu.py
```

**Output yang diharapkan:**

```
✅ GPU READY - OCR akan pakai GPU!
GPU Name: NVIDIA GeForce RTX 3050
CUDA Version: 11.8
```

### Test 2: OCR Service Health

```bash
curl http://localhost:5000/health
```

**Response harus show:**

```json
{
    "gpu": {
        "available": true,
        "device_name": "NVIDIA GeForce RTX 3050"
    }
}
```

### Test 3: Monitor GPU Usage

```bash
# Windows: Task Manager → Performance → GPU
# Atau PowerShell:
nvidia-smi
```

---

## 🎯 Hasil Setelah Setup

| Sebelum (CPU)               | Sesudah (GPU)             | Speedup   |
| --------------------------- | ------------------------- | --------- |
| OCR: ~5-10 detik            | OCR: ~1-2 detik           | **5-10x** |
| Expired Prediction: ~30-45s | Expired Prediction: ~5-8s | **6x**    |

---

## 🐛 Troubleshooting

### GPU tidak terdeteksi?

**1. Cek CUDA:**

```bash
nvcc --version
nvidia-smi
```

**2. Cek PyTorch:**

```python
python -c "import torch; print(torch.cuda.is_available())"
```

**3. Jika False, reinstall:**

```bash
pip uninstall torch torchvision
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

**4. Restart service:**

```bash
# Stop OCR service
# Start lagi
```

---

## 📝 Catatan

-   ✅ **Auto-fallback**: Jika GPU tidak tersedia, service otomatis pakai CPU (tidak error)
-   ✅ **Ollama**: Otomatis pakai GPU jika CUDA terinstall (tidak perlu setup khusus)
-   ✅ **Memory**: RTX 3050 (4GB VRAM) cukup untuk EasyOCR + Ollama gemma2:9b

---

## 🎉 Selesai!

Setelah setup, **restart OCR service** dan **restart Expired Prediction service**. GPU akan otomatis digunakan untuk mempercepat proses!

**Test dengan upload gambar receipt** → harus lebih cepat dari sebelumnya! 🚀
