# Setup GPU untuk RTX 3050 - Copy Paste Script
# Untuk laptop teman dengan NVIDIA RTX 3050

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup GPU untuk OCR & Expired Prediction" -ForegroundColor Cyan
Write-Host "  NVIDIA RTX 3050" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Cek CUDA
Write-Host "[1/4] Checking CUDA..." -ForegroundColor Yellow
try {
    $cudaVersion = nvcc --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✓ CUDA detected" -ForegroundColor Green
    } else {
        Write-Host "  ✗ CUDA not found" -ForegroundColor Red
        Write-Host "  → Download CUDA Toolkit: https://developer.nvidia.com/cuda-downloads" -ForegroundColor Yellow
        Write-Host "  → Install CUDA 11.8 atau 12.x" -ForegroundColor Yellow
        exit 1
    }
} catch {
    Write-Host "  ✗ CUDA not found" -ForegroundColor Red
    Write-Host "  → Download CUDA Toolkit: https://developer.nvidia.com/cuda-downloads" -ForegroundColor Yellow
    exit 1
}

# Step 2: Cek NVIDIA Driver
Write-Host "[2/4] Checking NVIDIA Driver..." -ForegroundColor Yellow
try {
    $nvidia = nvidia-smi 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✓ NVIDIA Driver detected" -ForegroundColor Green
    } else {
        Write-Host "  ✗ NVIDIA Driver not found" -ForegroundColor Red
        Write-Host "  → Install NVIDIA Driver dari: https://www.nvidia.com/drivers" -ForegroundColor Yellow
        exit 1
    }
} catch {
    Write-Host "  ✗ NVIDIA Driver not found" -ForegroundColor Red
    Write-Host "  → Install NVIDIA Driver dari: https://www.nvidia.com/drivers" -ForegroundColor Yellow
    exit 1
}

# Step 3: Install PyTorch dengan CUDA
Write-Host "[3/4] Installing PyTorch with CUDA 11.8..." -ForegroundColor Yellow
Write-Host "  → This may take a few minutes..." -ForegroundColor Gray

pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ PyTorch installed successfully" -ForegroundColor Green
} else {
    Write-Host "  ✗ PyTorch installation failed" -ForegroundColor Red
    Write-Host "  → Try: pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121" -ForegroundColor Yellow
    exit 1
}

# Step 4: Install EasyOCR (otomatis detect GPU)
Write-Host "[4/4] Installing EasyOCR..." -ForegroundColor Yellow
pip install easyocr

if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ EasyOCR installed successfully" -ForegroundColor Green
} else {
    Write-Host "  ✗ EasyOCR installation failed" -ForegroundColor Red
    exit 1
}

# Step 5: Verifikasi GPU
Write-Host ""
Write-Host "[VERIFY] Testing GPU detection..." -ForegroundColor Cyan
python -c "import torch; print('GPU Available:', torch.cuda.is_available()); print('GPU Name:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'N/A'); print('CUDA Version:', torch.version.cuda if torch.cuda.is_available() else 'N/A')"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  ✓ Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. Restart OCR service" -ForegroundColor White
Write-Host "  2. Test: curl http://localhost:5000/health" -ForegroundColor White
Write-Host "  3. Check GPU info in response" -ForegroundColor White
Write-Host ""
