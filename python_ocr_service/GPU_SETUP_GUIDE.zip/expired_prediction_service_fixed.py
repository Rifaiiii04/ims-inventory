# Temporary file to check indentation
# Line 458 area
def test_indent():
    try:
        if ai_reason:
            if reason_days is not None:
                pass
            else:
                print("INFO")
        
        today = datetime.now()
    except:
        pass
