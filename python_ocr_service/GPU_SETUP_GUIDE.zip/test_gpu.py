#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test GPU Detection untuk RTX 3050
Copy-paste script ini untuk test apakah GPU terdeteksi
"""

print("=" * 60)
print("  GPU Detection Test - RTX 3050")
print("=" * 60)
print()

# Test PyTorch
try:
    import torch
    print("✓ PyTorch installed")
    print(f"  Version: {torch.__version__}")
    
    # Check CUDA
    cuda_available = torch.cuda.is_available()
    print(f"\n✓ CUDA Available: {cuda_available}")
    
    if cuda_available:
        print(f"  ✓ GPU Count: {torch.cuda.device_count()}")
        print(f"  ✓ GPU Name: {torch.cuda.get_device_name(0)}")
        print(f"  ✓ CUDA Version: {torch.version.cuda}")
        print(f"  ✓ cuDNN Version: {torch.backends.cudnn.version()}")
        
        # Test GPU memory
        print(f"\n✓ GPU Memory:")
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            total_memory = props.total_memory / (1024**3)  # GB
            print(f"  GPU {i}: {total_memory:.2f} GB")
        
        print("\n" + "=" * 60)
        print("  ✅ GPU READY - OCR akan pakai GPU!")
        print("=" * 60)
    else:
        print("\n" + "=" * 60)
        print("  ⚠️  GPU NOT AVAILABLE - OCR akan pakai CPU")
        print("=" * 60)
        print("\nTroubleshooting:")
        print("  1. Install CUDA Toolkit: https://developer.nvidia.com/cuda-downloads")
        print("  2. Install PyTorch dengan CUDA:")
        print("     pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118")
        
except ImportError:
    print("✗ PyTorch not installed")
    print("\nInstall PyTorch dengan CUDA:")
    print("  pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118")
    exit(1)

# Test EasyOCR GPU
print("\n" + "=" * 60)
print("  Testing EasyOCR GPU Support")
print("=" * 60)

try:
    import easyocr
    print("✓ EasyOCR installed")
    
    # Try to initialize with GPU
    if cuda_available:
        try:
            print("  → Testing GPU initialization...")
            reader = easyocr.Reader(['en'], gpu=True)
            print("  ✅ EasyOCR GPU initialization SUCCESS")
            print("  → OCR akan pakai GPU (cepat!)")
        except Exception as e:
            print(f"  ⚠️  GPU initialization failed: {e}")
            print("  → OCR akan pakai CPU (lambat)")
    else:
        print("  → GPU not available, EasyOCR akan pakai CPU")
        
except ImportError:
    print("✗ EasyOCR not installed")
    print("\nInstall EasyOCR:")
    print("  pip install easyocr")

print("\n" + "=" * 60)
print("  Test Complete!")
print("=" * 60)
