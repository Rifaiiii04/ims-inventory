# 🚀 Panduan Setup GPU Acceleration untuk OCR & Expired Prediction

Panduan lengkap untuk mengaktifkan GPU acceleration agar proses OCR dan Expired Prediction lebih cepat.

## 📋 Prerequisites

### 1. GPU NVIDIA dengan CUDA Support

-   **Minimum**: NVIDIA GPU dengan CUDA Compute Capability 3.5+
-   **Recommended**: RTX series (RTX 3050, RTX 3060, dll)
-   **VRAM**: Minimum 2GB (Recommended 4GB+)

### 2. CUDA Toolkit

-   Download CUDA Toolkit dari: https://developer.nvidia.com/cuda-downloads
-   Install sesuai OS Anda (Windows/Linux/Mac)
-   **Catatan**: Mac tidak support CUDA, hanya Metal (Apple Silicon)

---

## 🔧 Setup GPU untuk OCR Service

### Step 1: Install CUDA Toolkit

**Windows:**

1. Download CUDA Toolkit dari: https://developer.nvidia.com/cuda-downloads
2. Pilih versi terbaru (CUDA 11.8 atau 12.x)
3. Install dengan default settings
4. Pastikan CUDA ditambahkan ke PATH

**Linux:**

```bash
# Ubuntu/Debian
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt-get update
sudo apt-get -y install cuda-toolkit-11-8
```

**Verifikasi CUDA:**

```bash
nvcc --version
nvidia-smi
```

### Step 2: Install PyTorch dengan CUDA Support

**Windows/Linux (CUDA 11.8):**

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

**Windows/Linux (CUDA 12.1):**

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

**CPU Only (jika tidak punya GPU):**

```bash
pip install torch torchvision
```

### Step 3: Install EasyOCR dengan GPU Support

EasyOCR akan otomatis detect GPU jika PyTorch dengan CUDA sudah terinstall:

```bash
pip install easyocr
```

### Step 4: Verifikasi GPU Detection

Test apakah GPU terdeteksi:

```python
import torch
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"CUDA version: {torch.version.cuda}")
print(f"GPU count: {torch.cuda.device_count()}")
if torch.cuda.is_available():
    print(f"GPU name: {torch.cuda.get_device_name(0)}")
```

Atau test via OCR service:

```bash
curl http://localhost:5000/health
```

Response akan menampilkan:

```json
{
    "gpu": {
        "available": true,
        "device_count": 1,
        "device_name": "NVIDIA GeForce RTX 3050",
        "cuda_version": "11.8"
    }
}
```

---

## 🔧 Setup GPU untuk Ollama (Expired Prediction)

Ollama otomatis menggunakan GPU jika CUDA terinstall. Tidak perlu konfigurasi khusus di Python service.

### Verifikasi Ollama GPU Usage

**Cek apakah Ollama pakai GPU:**

```bash
# Windows PowerShell
nvidia-smi

# Atau monitor GPU usage saat Ollama running
```

**Test Ollama dengan GPU:**

```bash
ollama run gemma2:9b "Test GPU"
# Monitor GPU usage di Task Manager atau nvidia-smi
```

**Force Ollama pakai GPU (jika tidak otomatis):**

```bash
# Set environment variable
export OLLAMA_NUM_GPU=1

# Windows PowerShell
$env:OLLAMA_NUM_GPU=1
ollama run gemma2:9b "Test"
```

---

## 📊 Performance Comparison

### OCR Service (EasyOCR)

| Hardware       | Speed                 | Accuracy |
| -------------- | --------------------- | -------- |
| CPU (Intel i5) | ~5-10 detik/gambar    | ✅ Sama  |
| GPU (RTX 3050) | ~1-2 detik/gambar     | ✅ Sama  |
| **Speedup**    | **5-10x lebih cepat** | -        |

### Expired Prediction (Ollama)

| Model      | CPU     | GPU (RTX 3050) | Speedup  |
| ---------- | ------- | -------------- | -------- |
| gemma2:2b  | ~10-15s | ~2-3s          | **5x**   |
| gemma2:9b  | ~30-45s | ~5-8s          | **6x**   |
| gemma2:27b | ~120s+  | ~15-20s        | **6-8x** |

---

## 🐛 Troubleshooting

### Issue 1: GPU tidak terdeteksi

**Gejala:**

```python
torch.cuda.is_available()  # Returns False
```

**Solusi:**

1. Pastikan CUDA Toolkit terinstall: `nvcc --version`
2. Pastikan PyTorch dengan CUDA terinstall:
    ```bash
    python -c "import torch; print(torch.cuda.is_available())"
    ```
3. Reinstall PyTorch dengan CUDA:
    ```bash
    pip uninstall torch torchvision
    pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
    ```

### Issue 2: EasyOCR fallback ke CPU

**Gejala:**

```
EasyOCR initialized with CPU
```

**Solusi:**

1. Cek apakah PyTorch detect GPU:
    ```python
    import torch
    print(torch.cuda.is_available())
    ```
2. Jika False, install PyTorch dengan CUDA (lihat Step 2)
3. Restart OCR service

### Issue 3: Out of Memory (OOM)

**Gejala:**

```
RuntimeError: CUDA out of memory
```

**Solusi:**

1. Kurangi batch size di EasyOCR (tidak bisa diubah langsung, tapi bisa process gambar satu per satu)
2. Gunakan model yang lebih kecil untuk Ollama (gemma2:2b instead of 9b)
3. Tutup aplikasi lain yang pakai GPU
4. Restart service

### Issue 4: CUDA version mismatch

**Gejala:**

```
CUDA runtime version mismatch
```

**Solusi:**

1. Cek CUDA version: `nvcc --version`
2. Install PyTorch dengan CUDA version yang sesuai:
    - CUDA 11.8 → `pip install torch --index-url https://download.pytorch.org/whl/cu118`
    - CUDA 12.1 → `pip install torch --index-url https://download.pytorch.org/whl/cu121`

---

## ✅ Checklist Setup GPU

-   [ ] CUDA Toolkit terinstall (`nvcc --version`)
-   [ ] NVIDIA Driver terinstall (`nvidia-smi`)
-   [ ] PyTorch dengan CUDA terinstall (`torch.cuda.is_available()` = True)
-   [ ] EasyOCR detect GPU (cek `/health` endpoint)
-   [ ] Ollama pakai GPU (monitor dengan `nvidia-smi`)
-   [ ] Test OCR dengan GPU (harus lebih cepat dari CPU)
-   [ ] Test Expired Prediction dengan GPU (harus lebih cepat)

---

## 🎯 Quick Start (Copy-Paste)

**Windows (PowerShell):**

```powershell
# 1. Install PyTorch dengan CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# 2. Install EasyOCR (otomatis detect GPU)
pip install easyocr

# 3. Verifikasi
python -c "import torch; print('GPU:', torch.cuda.is_available())"

# 4. Restart OCR service
# Service akan otomatis pakai GPU jika tersedia
```

**Linux:**

```bash
# 1. Install PyTorch dengan CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# 2. Install EasyOCR
pip install easyocr

# 3. Verifikasi
python -c "import torch; print('GPU:', torch.cuda.is_available())"

# 4. Restart OCR service
```

---

## 📝 Catatan Penting

1. **GPU Memory**: EasyOCR butuh ~1-2GB VRAM, Ollama butuh 2-8GB tergantung model
2. **Fallback**: Jika GPU tidak tersedia, service otomatis pakai CPU (tidak error)
3. **Multi-GPU**: Jika punya multiple GPU, bisa set `CUDA_VISIBLE_DEVICES=0` untuk pilih GPU tertentu
4. **Docker**: Jika pakai Docker, perlu mount GPU dengan `--gpus all` flag

---

## 🐳 Docker dengan GPU Support

Jika pakai Docker, tambahkan GPU support:

```bash
# Run dengan GPU support
docker run --gpus all -p 5000:5000 your-ocr-service

# Atau di docker-compose.yml
services:
  ocr_service:
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
```

---

## 📚 Referensi

-   PyTorch CUDA Installation: https://pytorch.org/get-started/locally/
-   EasyOCR Documentation: https://github.com/JaidedAI/EasyOCR
-   Ollama GPU Support: https://github.com/ollama/ollama/blob/main/docs/gpu.md
-   CUDA Toolkit: https://developer.nvidia.com/cuda-downloads
